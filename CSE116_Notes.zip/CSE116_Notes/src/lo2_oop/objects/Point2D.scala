package lo2_oop.objects

class Point2D(var x: Double, var y: Double) {

}
