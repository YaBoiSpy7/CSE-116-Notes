package lo2_oop.memory.rpg_example

class PartyCharacter() {

  var battlesWon: Int = 0
  var experiencePoints: Int = 0

}
