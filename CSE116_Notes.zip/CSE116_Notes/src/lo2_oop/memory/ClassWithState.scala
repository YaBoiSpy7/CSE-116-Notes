package lo2_oop.memory

class ClassWithState(var state: Int) {

}
