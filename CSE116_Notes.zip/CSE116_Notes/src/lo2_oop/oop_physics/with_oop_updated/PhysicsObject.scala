package lo2_oop.oop_physics.with_oop_updated

import archived.physics.PhysicsVector

class PhysicsObject(var location: PhysicsVector) {

  // Physics functionality not implemented

}
