package lo3_fp.concurrency.mmo

case object Update
