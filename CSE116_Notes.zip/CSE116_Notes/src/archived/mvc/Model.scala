package archived.mvc

class Model {

  def sendMessage(message: String): Unit = {}

  def allMessages(): List[String] = {
    List()
  }

}
