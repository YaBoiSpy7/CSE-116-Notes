package archived.physics

/**
  * Controls and computes the simulated archived.physics for a game. Manages dynamic object movement, gravity, and
  * object collisions
  */
object PhysicsEngine {


  // No solutions


  def updateWorld(world: World, deltaTime: Double): Unit = {

  }


}
