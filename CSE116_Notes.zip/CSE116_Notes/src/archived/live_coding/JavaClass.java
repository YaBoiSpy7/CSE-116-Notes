package archived.live_coding;

public class JavaClass {

    public static void doesNothing(){
        System.out.println("hi from Java!!!");
    }

}
