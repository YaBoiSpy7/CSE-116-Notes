package archived.live_coding

class GrassType(name: String) extends Pokemon(name) {

  override val pokemonType: String = "grass"
//  pokemonType = "grass"

}
