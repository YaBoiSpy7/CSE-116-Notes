package archived.live_coding

class Bulbusaur extends GrassType("Bulbasaur") {


}


// IntelliJ
// -specific suggestions