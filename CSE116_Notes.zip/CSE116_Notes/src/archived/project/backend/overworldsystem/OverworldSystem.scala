package archived.project.backend.overworldsystem

import akka.actor.{Actor, ActorRef}


class OverworldSystem(server: ActorRef) extends Actor {

  override def receive: Receive = {
    case _ =>
  }

}
