package lo4_data_structures.linkedlist.equipment

class GoldMines extends Equipment{

  this.name = "Gold Mine"

}
