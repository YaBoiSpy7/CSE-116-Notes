package lo4_data_structures.linkedlist.equipment

class Shovels extends Equipment {

  this.name = "Shovel"


}
