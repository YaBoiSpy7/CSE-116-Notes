package lo4_data_structures.linkedlist.equipment

class Excavators extends Equipment{

  this.name = "Excavator"


}
